﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Xml;

namespace IP_Checker
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer _monitoringTimer;
        private bool _isMonitoring = false;

        public MainWindow()
        {
            InitializeComponent();
            InitializeTimer();
            rbUrl.Checked += CheckType_Changed;
            rbIp.Checked += CheckType_Changed;
            rbPhone.Checked += CheckType_Changed;
        }

        private void CheckType_Changed(object sender, RoutedEventArgs e)
        {
            if (rbUrl.IsChecked == true)
            {
                lblInput.Text = "URL сайта:";
                txtInput.Text = "http://";
                tabGeo.Visibility = Visibility.Visible;
            }
            else if (rbIp.IsChecked == true)
            {
                lblInput.Text = "IP адрес:";
                txtInput.Text = "";
                tabGeo.Visibility = Visibility.Visible;
            }
            else if (rbPhone.IsChecked == true)
            {
                lblInput.Text = "Номер телефона:";
                txtInput.Text = "";
                tabGeo.Visibility = Visibility.Collapsed;
            }
        }

        private void InitializeTimer()
        {
            _monitoringTimer = new DispatcherTimer();
            _monitoringTimer.Tick += MonitoringTimer_Tick;
        }

        private async void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            await CheckTarget();
        }

        private async void btnStartMonitoring_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput())
                return;

            if (!int.TryParse(txtInterval.Text, out int interval) || interval <= 0)
            {
                MessageBox.Show("Пожалуйста, введите корректный интервал (положительное число)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            _monitoringTimer.Interval = TimeSpan.FromSeconds(interval);
            _monitoringTimer.Start();
            _isMonitoring = true;
            btnStartMonitoring.IsEnabled = false;
            btnStopMonitoring.IsEnabled = true;
            btnCheck.IsEnabled = false;
            txtStatus.Text = "Мониторинг запущен";

            await CheckTarget();
        }

        private bool ValidateInput()
        {
            string input = txtInput.Text.Trim();

            if (rbUrl.IsChecked == true)
            {
                if (string.IsNullOrWhiteSpace(input) || !Uri.TryCreate(input, UriKind.Absolute, out _))
                {
                    MessageBox.Show("Пожалуйста, введите корректный URL", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else if (rbIp.IsChecked == true)
            {
                if (!IPAddress.TryParse(input, out _))
                {
                    MessageBox.Show("Пожалуйста, введите корректный IP-адрес", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            else if (rbPhone.IsChecked == true)
            {
                string phonePattern = @"^\+?[0-9\s\-\(\)]{7,}$";
                if (!Regex.IsMatch(input, phonePattern))
                {
                    MessageBox.Show("Пожалуйста, введите корректный номер телефона", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            return true;
        }

        private void btnStopMonitoring_Click(object sender, RoutedEventArgs e)
        {
            _monitoringTimer.Stop();
            _isMonitoring = false;
            btnStartMonitoring.IsEnabled = true;
            btnStopMonitoring.IsEnabled = false;
            btnCheck.IsEnabled = true;
            txtStatus.Text = "Мониторинг остановлен";
        }

        private async void MonitoringTimer_Tick(object sender, EventArgs e)
        {
            await CheckTarget();
        }

        private async Task CheckTarget()
        {
            try
            {
                if (!ValidateInput())
                    return;

                string input = txtInput.Text.Trim();
                txtStatus.Text = "Проверка...";
                AddLog($"Начата проверка: {input}");

                // Очищаем предыдущие результаты
                pnlHostInfo.Children.Clear();
                pnlGeoInfo.Children.Clear();

                if (rbUrl.IsChecked == true)
                {
                    await CheckUrl(input);
                }
                else if (rbIp.IsChecked == true)
                {
                    await CheckIp(input);
                }
                else if (rbPhone.IsChecked == true)
                {
                    await CheckPhone(input);
                }

                txtLastUpdate.Text = $"Последняя проверка: {DateTime.Now:HH:mm:ss}";
                txtStatus.Text = "Проверка завершена";
                AddLog($"Проверка завершена: {input}");
            }
            catch (Exception ex)
            {
                AddLog($"Ошибка: {ex.Message}");
                txtStatus.Text = "Ошибка при проверке";
            }
        }

        private async Task CheckUrl(string url)
        {
            Uri uri = new Uri(url);
            string host = uri.Host;
            IPHostEntry hostEntry = await Dns.GetHostEntryAsync(host);

            AddHostInfo("URL сайта:", url);
            AddHostInfo("Имя хоста:", hostEntry.HostName);

            // IP адреса
            AddHostInfo("IP адреса:", "");
            foreach (IPAddress address in hostEntry.AddressList)
            {
                AddHostInfo("", $"• {address} ({GetAddressFamily(address.AddressFamily)})");
                await ShowGeoInfo(address.ToString());
            }

            // Проверка доступности
            bool isReachable = await PingHost(host);
            AddHostInfo("Доступность:", isReachable ? "Доступен" : "Недоступен");

            // Проверка HTTP статуса
            HttpStatusCode? statusCode = await GetHttpStatus(uri);
            AddHostInfo("HTTP статус:", statusCode?.ToString() ?? "Не удалось получить статус");

            // Время ответа
            long pingTime = await GetPingTime(host);
            AddHostInfo("Время ответа (мс):", pingTime >= 0 ? pingTime.ToString() : "Не удалось измерить");
        }

        private async Task CheckIp(string ip)
        {
            AddHostInfo("IP адрес:", ip);
            AddHostInfo("Тип адреса:", GetAddressFamily(IPAddress.Parse(ip).AddressFamily));

            // Проверка доступности
            bool isReachable = await PingHost(ip);
            AddHostInfo("Доступность:", isReachable ? "Доступен" : "Недоступен");

            // Время ответа
            long pingTime = await GetPingTime(ip);
            AddHostInfo("Время ответа (мс):", pingTime >= 0 ? pingTime.ToString() : "Не удалось измерить");

            // Геоинформация
            await ShowGeoInfo(ip);
        }

        private async Task CheckPhone(string phone)
        {
            // Очистка номера от лишних символов
            string cleanPhone = Regex.Replace(phone, @"[^\d]", "");

            AddHostInfo("Номер телефона:", FormatPhoneNumber(phone));
            AddHostInfo("Код страны:", GetCountryCode(cleanPhone));
            AddHostInfo("Возможный оператор:", await IdentifyOperator(cleanPhone));
            AddHostInfo("Валидность:", ValidatePhoneNumber(cleanPhone) ? "Валидный" : "Невалидный");
        }

        private string FormatPhoneNumber(string phone)
        {
            // Простое форматирование для отображения
            return Regex.Replace(phone, @"(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})", "+$1 ($2) $3-$4-$5");
        }

        private string GetCountryCode(string phone)
        {
            if (phone.StartsWith("7")) return "Россия (+7)";
            if (phone.StartsWith("380")) return "Украина (+380)";
            if (phone.StartsWith("375")) return "Беларусь (+375)";
            if (phone.StartsWith("77")) return "Казахстан (+7)";
            if (phone.StartsWith("1")) return "США/Канада (+1)";
            return "Неизвестно";
        }

        private async Task<string> IdentifyOperator(string phone)
        {
            // Здесь можно добавить реальную проверку через API
            // Это примерная реализация для России
            if (phone.StartsWith("79"))
            {
                return await Task.Run(() =>
                {
                    // Имитация проверки оператора
                    string[] operators = { "МТС", "МегаФон", "Билайн", "Теле2", "Yota" };
                    return operators[new Random().Next(operators.Length)];
                });
            }
            return "Неизвестно";
        }

        private bool ValidatePhoneNumber(string phone)
        {
            // Простая валидация длины номера
            return phone.Length >= 7 && phone.Length <= 15;
        }

        private async Task ShowGeoInfo(string ip)
        {
            try
            {
                // Используем бесплатный API для получения геоданных
                string apiUrl = $"http://ip-api.com/xml/{ip}";

                using (HttpClient client = new HttpClient())
                {
                    string response = await client.GetStringAsync(apiUrl);
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(response);

                    AddGeoInfo("Страна:", GetXmlValue(xmlDoc, "country"));
                    AddGeoInfo("Код страны:", GetXmlValue(xmlDoc, "countryCode"));
                    AddGeoInfo("Регион:", GetXmlValue(xmlDoc, "regionName"));
                    AddGeoInfo("Город:", GetXmlValue(xmlDoc, "city"));
                    AddGeoInfo("Почтовый индекс:", GetXmlValue(xmlDoc, "zip"));
                    AddGeoInfo("Часовой пояс:", GetXmlValue(xmlDoc, "timezone"));
                    AddGeoInfo("Провайдер:", GetXmlValue(xmlDoc, "isp"));
                    AddGeoInfo("Организация:", GetXmlValue(xmlDoc, "org"));
                }
            }
            catch (Exception ex)
            {
                AddGeoInfo("Ошибка:", $"Не удалось получить геоданные: {ex.Message}");
            }
        }

        private string GetXmlValue(XmlDocument doc, string nodeName)
        {
            XmlNode node = doc.SelectSingleNode($"//{nodeName}");
            return node?.InnerText ?? "Недоступно";
        }

        private void AddHostInfo(string label, string value)
        {
            AddInfoToPanel(pnlHostInfo, label, value);
        }

        private void AddGeoInfo(string label, string value)
        {
            AddInfoToPanel(pnlGeoInfo, label, value);
        }

        private void AddInfoToPanel(StackPanel panel, string label, string value)
        {
            if (!string.IsNullOrEmpty(label))
            {
                panel.Children.Add(new TextBlock
                {
                    Text = label,
                    FontWeight = FontWeights.Bold,
                    Margin = new Thickness(0, 5, 0, 0)
                });
            }

            panel.Children.Add(new TextBlock
            {
                Text = value,
                Margin = new Thickness(10, 0, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });
        }

        private void AddLog(string message)
        {
            Dispatcher.Invoke(() =>
            {
                txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                txtLog.ScrollToEnd();
            });
        }

        private async Task<bool> PingHost(string host)
        {
            try
            {
                using (Ping ping = new Ping())
                {
                    PingReply reply = await ping.SendPingAsync(host);
                    return reply.Status == IPStatus.Success;
                }
            }
            catch
            {
                return false;
            }
        }

        private async Task<long> GetPingTime(string host)
        {
            try
            {
                using (Ping ping = new Ping())
                {
                    PingReply reply = await ping.SendPingAsync(host);
                    return reply.RoundtripTime;
                }
            }
            catch
            {
                return -1;
            }
        }

        private async Task<HttpStatusCode?> GetHttpStatus(Uri uri)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(uri);
                    return response.StatusCode;
                }
            }
            catch
            {
                return null;
            }
        }

        private string GetAddressFamily(AddressFamily family)
        {
            return family == AddressFamily.InterNetwork ? "IPv4" :
                   family == AddressFamily.InterNetworkV6 ? "IPv6" :
                   family.ToString();
        }

        protected override void OnClosed(EventArgs e)
        {
            if (_isMonitoring)
            {
                _monitoringTimer.Stop();
            }
            base.OnClosed(e);
        }
    }
}